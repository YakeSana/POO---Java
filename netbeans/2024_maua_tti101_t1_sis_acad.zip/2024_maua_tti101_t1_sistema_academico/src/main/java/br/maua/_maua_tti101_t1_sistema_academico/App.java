/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.maua._maua_tti101_t1_sistema_academico;

/**
 *
 * @author 23.10270-5
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
