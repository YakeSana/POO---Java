/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.maua._maua_tti101_t1_sistema_academico.bd;

/**
 *
 * @author 23.10270-5
 */
public class UsuarioDAO {
    
    
}
