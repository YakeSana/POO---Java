-- Active: 1713439423447@@mysql-3a5d9492-mitchellmiyake-4c6f.b.aivencloud.com@27171@defaultdb

-- 1.criar tabela
CREATE TABLE tb_usuario_AivenPoo(
    cod_usuario INT PRIMARY KEY AUTO_INCREMENT,
    login VARCHAR(200) NOT NULL,
    senha VARCHAR(200) NOT NULL,
    tipo_usuario INT NOT NULL
);

-- 2.cadastrar dois usuarios

INSERT INTO tb_usuario_AivenPoo 
(login,senha,tipo_usuario)
VALUES
('admin','admin',1),
('admin2','admin2',1)

INSERT INTO tb_usuario_AivenPoo 
(login,senha,tipo_usuario)
VALUES
('comum','comum',2)
-- 3.visualizar dados de usuarios

SELECT * FROM tb_usuario_AivenPoo

-- 4.atualizar dados de usuarios

UPDATE tb_usuario_AivenPoo SET
login = 'admin', senha = '123456' 
WHERE cod_usuario = 1;

-- 5.apagar um usuario

DELETE FROM tb_usuario_AivenPoo WHERE cod_usuario = 2;

-- 6.Adicinar uma coluna chamada ativo booleana que indica se o usuario esta ativo ou nao valor padrao true

ALTER Table tb_usuario_AivenPoo ADD COLUMN ativo_booleana BOOLEAN DEFAULT TRUE;
