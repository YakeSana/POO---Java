/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.maua._maua_tti101_t1_sistema_academico.bd;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author 23.10270-5
 */
public class ConnectionFactory {

    private String host = "mysql-3a5d9492-mitchellmiyake-4c6f.b.aivencloud.com";
    private String port = "27171";
    private String db = "defaultdb";
    private String user = "avnadmin";
    private String password = "AVNS_pEqd2qXck9sUx2jy-Er";

    public Connection obterConexao() throws Exception {
        //jdbc:mysql://host:port/db isso é uma string de conexao
        //catch or declare
        var stringConexao = String.format(
                "jdbc:mysql://%s:%s/%s", host, port, db
        );
        Connection conexao = DriverManager.getConnection(stringConexao, user, password);
        return conexao;

    }
;

}
